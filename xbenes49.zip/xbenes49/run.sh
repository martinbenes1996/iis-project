#!/usr/bin/env bash

cd project
python3 manage.py runserver
