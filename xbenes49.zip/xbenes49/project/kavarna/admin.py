from django.contrib import admin
from kavarna import models

admin.site.register(models.Coffee)
admin.site.register(models.Cafe)
admin.site.register(models.Drinker)
